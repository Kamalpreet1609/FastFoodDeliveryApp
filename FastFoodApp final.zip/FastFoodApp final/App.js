import React from 'react';
import { StyleSheet } from 'react-native';
import { createStore, combineReducers } from "redux";
import { Provider } from "react-redux";
import AppContainer from "./Navigation/NavigationConfig"
import ProductsReducers from "./Store/Reducers/ProductsReducers";
import CartReducers from "./Store/Reducers/CartReducers";
import Constants from "expo-constants";
import ProductsList from './Screens/Data';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");

const RootReducer = combineReducers({
  products: ProductsReducers,
  cartItems: CartReducers,
  itemsCount: CartReducers,
  wishListItems: CartReducers
});
const store = createStore(RootReducer);
const categories = [
  { id: "1", title: "Burgers", image: "https://7esl.com/wp-content/uploads/2017/12/hamburger-150x150.png" },
  { id: "2", title: "Sandwich", image: "https://7esl.com/wp-content/uploads/2017/12/sandwich3-1-150x150.png" },
  { id: "4", title: "Pizza", image: "https://7esl.com/wp-content/uploads/2017/12/pizza-1-150x150.png" },
  { id: "5", title: "Noodle", image: "https://7esl.com/wp-content/uploads/2017/12/Copy-of-Fast-foods-150x150.png" },
  { id: "8", title: "Hot dog", image: "https://7esl.com/wp-content/uploads/2017/12/hot-dog-1-150x150.png" },
  { id: "9", title: "Burrito", image: "https://7esl.com/wp-content/uploads/2017/12/breakfast-burrito-150x150.png" },
  { id: "6", title: "Milk shake", image: "https://7esl.com/wp-content/uploads/2017/12/milkshake1-2-150x150.png" },
  { id: "7", title: "Soft drink", image: "https://7esl.com/wp-content/uploads/2017/12/soft-drink-150x150.png" },
];

const App = () => {
  db.transaction(tx => {
    tx.executeSql(
      "create table if not exists users (uid integer primary key AUTOINCREMENT, name text not null,email text unique ,pwd text not null, is_active int default 0,isAdmin int not null);"
     //"Drop table users"
      , []
      , (transact, resultset) => { }//console.log('Query Reslts users: ', resultset)
      , (transact, err) => console.log('We have encounter an Error', err)
    );

    tx.executeSql(
     "create table if not exists cart (cid integer primary key AUTOINCREMENT, p_name text not null, p_image text not null,price text ,qty int not null, p_id int not null);"
     //"Drop table cart"
      , []
      , (transact, resultset) => { console.log('Query Reslts cart: ', resultset)}//
      , (transact, err) => console.log('We have encounter an Error', err)
    );

    tx.executeSql(
      "create table if not exists orders (oid integer primary key AUTOINCREMENT, title text not null, ammount text not null, status text not null, uid int not null);"
     //"Drop table orders"
      , []
      , (transact, resultset) => { console.log('Query Reslts orders: ', resultset)}//
      , (transact, err) => console.log('We have encounter an Error', err)
    );
    //
    tx.executeSql(
      "create table if not exists order_products (op_id integer primary key AUTOINCREMENT, p_name text not null,p_image text not null,price text ,qty int not null, oid int not null, uid int not null);"
     //"Drop table order_products"
      , []
      , (transact, resultset) => { console.log('Query Reslts order_products: ', resultset)}//
      , (transact, err) => console.log('We have encounter an Error', err)
    );


    tx.executeSql(
      "create table if not exists categories (id integer primary key AUTOINCREMENT, title text not null unique,image text not null);"
      //  "Drop table categories"
      , []
      , (transact, resultset) => {
        tx.executeSql("select * from categories ", [], (_, { rows }) => {
          if (rows.length < 1) {
            for (let i = 0; i < categories.length; i++) {
              let trxQuery = tx.executeSql(
                "insert into categories (title, image) values (?, ?)"
                , [categories[i].title, categories[i].image]
                , (transact, resultset) => {
                  console.log('Query Reslts Cat: ' + categories[i].title)
                }
                , (transact, err) => {
                  console.log('We have encounter an Error Cat', err)
                }
              );
            }
          } else {
            console.log('Categories already exixts');
          }
        }, (transact, err) => {
          console.log('We have encounter an Error', err)
        }
        );
      }
      , (transact, err) => console.log('We have encounter an Error', err)
    );

    tx.executeSql(
      "create table if not exists products (id integer primary key AUTOINCREMENT, category text not null, title text not null,Description text not null, rating text,Price text not null, favourite boolean,image text not null);"
      //"Drop table products"
      , []
      , (transact, resultset) => {
        tx.executeSql("select * from products ", [], (_, { rows }) => {
          if (rows.length < 1) {
            for (let i = 0; i < ProductsList.length; i++) {
              let trxQuery = tx.executeSql(
                "insert into products (category, title, Description, rating, Price, favourite, image) values (?,?,?,?,?,'false',?)"
                , [ProductsList[i].category, ProductsList[i].title, ProductsList[i].Description, ProductsList[i].rating,
                ProductsList[i].Price,ProductsList[i].image]
                , (transact, resultset) => {
                  console.log('Query Reslts products: ' + ProductsList[i].title)
                }
                , (transact, err) => {
                  console.log('We have encounter an Error product', err)
                }
              );
            }
          } else {
            console.log('Products already exixts');
          }
        }, (transact, err) => {
          console.log('We have encounter an Error', err)
        }
        );
      }
      , (transact, err) => console.log('We have encounter an Error', err)
    );

  });

  return (
    <Provider store={store}>
      <AppContainer />
    </Provider>
  );
};

const styles = StyleSheet.create({
  main: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center"
  }
});

export default App;
