import ProductsList from "../../Screens/Data";
const initialState = {
    products : ProductsList,

}

export default (state = initialState, action)=>{
    
        return state;
}





