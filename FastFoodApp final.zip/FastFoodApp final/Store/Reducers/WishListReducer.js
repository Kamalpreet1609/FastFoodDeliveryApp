const initialState = {
    wishListItems : [],
}
export default (state=initialState, action)=>{
    return state;
}