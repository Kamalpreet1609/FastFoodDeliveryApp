import React from "react";
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import Icon from 'react-native-vector-icons/FontAwesome5';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import Fontisto from 'react-native-vector-icons/Fontisto';
import CategoriesScreen from "../Screens/CategoriesScreen";
import AllProductsScreen from "../Screens/AllProductsScreen";
import WishListScreen from "../Screens/WishListScreen";
import CartScreen from "../Screens/CartScreen";
import CategoriesProductsScreen from "../Screens/CategoriesProductsScreen";
import ProductsDetailScreen from "../Screens/ProductsDetailScreen";
import OrdersScreen from "../Screens/OrdersScreen";
import Login from "../Screens/login";
import Signup from "../Screens/Signup";
import Profile from "../Screens/Profile";
import Categories from "../Screens/Admin/Categories";
import AddCategory from "../Screens/Admin/AddCategory"
import ManageProducts from "../Screens/Admin/ManageProducts";
import EditProduct from "../Screens/Admin/EditProduct";
import AllUsers from "../Screens/Admin/AllUsers";
import UserOrders from "../Screens/Admin/UserOrders";
const defaultOptionsForStack = {
    defaultNavigationOptions: {

        headerStyle: {
            backgroundColor: '#0F9E54',
            elevation: 0,
            shadowOpacity: 0
        },
        headerTintColor: '#FFFFFF',
        headerTitleStyle: {
            fontWeight: 'bold',
            color: '#FFFFFF',
            fontSize: 18
        }
    }

};

const CategoriesStack = createStackNavigator({
    Categories: {
        screen: CategoriesScreen,
        navigationOptions: {
            headerTitle: "Food Categories"
        }
    },
    CategoriesProducts: {
        screen: CategoriesProductsScreen,

    },
    ProductDetails: {
        screen: ProductsDetailScreen,

    },
    Cart: {
        screen: CartScreen
    }

}, defaultOptionsForStack

);

const AllProductsStack = createStackNavigator({

    AllProducts: {
        screen: AllProductsScreen,
        navigationOptions: {
            headerTitle: "All Products"
        }
    },
    ProductDetails: {
        screen: ProductsDetailScreen,

    },
    Cart: {
        screen: CartScreen
    }

}, defaultOptionsForStack

);


const WishListStack = createStackNavigator({

    WishList: {
        screen: OrdersScreen,
        navigationOptions: {
            headerTitle: "Orders Screen"
        }
    },
    ProductDetails: {
        screen: ProductsDetailScreen,
    },
    Cart: {
        screen: CartScreen
    }

}, defaultOptionsForStack

);


const AuthStack = createStackNavigator({

    Profile: {
        screen: Profile,
        navigationOptions: {
            headerTitle: "Profile"
        }
    }, Login: {
        screen: Login,
        navigationOptions: {
            headerTitle: "Login"
        }
    },
    Signup: {
        screen: Signup,
        navigationOptions: {
            headerTitle: "Sign Up"
        }
    },
    Orders: {
        screen: OrdersScreen,
        navigationOptions: {
            headerTitle: "My Orders"
        }
    },
    Categories: {
        screen: Categories,
        navigationOptions: {
            headerTitle: "All Categories"
        }
    },
    AddCategory: {
        screen: AddCategory,
    },
    ManageProducts: {
        screen: ManageProducts,
        navigationOptions: {
            headerTitle: "All Products"
        }
    },
    EditProduct: {
        screen: EditProduct,
    },
    AllUsers: {
        screen: AllUsers,
        navigationOptions: {
            headerTitle: "All Customers"
        }
    }, UserOrders: {
        screen: UserOrders,
    },


}, defaultOptionsForStack
);

const CartStack = createStackNavigator({

    Cart: {
        screen: CartScreen,
        navigationOptions: {
            headerTitle: "Items in Cart"
        }
    }, Login: {
        screen: Login,
        navigationOptions: {
            headerTitle: "Login"
        }
    },
    Signup: {
        screen: Signup,
        navigationOptions: {
            headerTitle: "Sign Up"
        }
    }



}, defaultOptionsForStack

);





const TabNavigator = createBottomTabNavigator({
    Categories: {
        screen: CategoriesStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor }) => {
                return <FontAwesome name="home" size={20} color={tintColor} />
            }

        },


    }, 
    Cart: {
        screen: CartStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor }) => {
                return <Icon name="shopping-cart" size={20} color={tintColor} />
            }
        }
    },
    "Profile": {
        screen: AuthStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor }) => {
                return <Icon name="user" size={20} color={tintColor} />
            }
        }
    },
}, {
    tabBarOptions: {
        showLabel: false,
        activeTintColor: "#0F9E54",
        inactiveTintColor: "black",
        tabStyle: { height: 50, zIndex: 99, borderColor: "white", borderTopWidth: 0 },
        labelStyle: { fontSize: 12, paddingTop: 2, paddingBottom: 3, },
    }
}


);



const AppContainer = createAppContainer(TabNavigator)

export default AppContainer;











