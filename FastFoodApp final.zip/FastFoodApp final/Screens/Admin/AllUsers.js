import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  Button
} from 'react-native';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");
import AsyncStorage from '@react-native-async-storage/async-storage'

class AllUsers extends Component {
  state = {
    itemsInList: null,
    userSession: null
  }
 
  checkLogin = () => {
    AsyncStorage.getItem("userSession").then((value) => {
      console.log('Login Session OrderScreen', JSON.parse(value));
      this.setState({
        userSession: JSON.parse(value)
      });
      this.getUserList();
    });
  }
  componentDidMount = () => {
    this.checkLogin();
  }
  getUserList = ()=>{
    db.transaction(
        tx => {
          tx.executeSql(
            "select * from users"
            , [], (_, { rows }) => {
              console.log('UserList', rows)
              this.setState({
                itemsInList: rows._array
              });
            }
            , (transact, err) => {
              console.log('We have encounter an Error', err)
            }
          );
        },
      );
  }
 

  loadBooks = (book) => {
    let newBook = {
      id: book.item.uid,
      name: book.item.name,
      email: book.item.email,
    }
    return (
      <TouchableOpacity onPress={
        () => {
            this.props.navigation.navigate("UserOrders",
            { newBook });
        }
      }>
        <View style={styles.productMain}>
          <View style={{ justifyContent: "space-around", alignContent: "center", marginLeft: 20, }}>
            <View style={{ overFlow: "hidden" }}>
            <Text style={styles.text}>Customer Id : {book.item.uid}</Text>
              <Text numberOfLines={2} style={styles.text}>Customer Name: {book.item.name}</Text>
            </View>
            <Text style={styles.text}>Email : {book.item.email}</Text>
          </View>
          <View style={{ width: "35%", height: 50, }}>
          </View>
        </View>
      </TouchableOpacity>
    )

  }

  render() {
    return (
      <View style={styles.main}>
       
        <FlatList data={this.state.itemsInList}
        keyExtractor={(item, index) => index+''}
        renderItem={
          this.loadBooks
        }
        />
      </View>
    )
  }
}
const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 10,

  },
  bookMain: {
    marginTop: 10,
    width: "100%",
    height: 500,

    borderColor: "black", borderWidth: 1,
    borderRadius: 5
  },
  productMain: {
    flexDirection: "row",
    justifyContent: "flex-start",
    borderBottomColor: "gray",
    borderBottomWidth: 1,
    marginBottom: 5


  },
  text: {
    color: "black",
    fontSize: 15,
    fontWeight: "bold",
    overflow: "hidden",
    width: "100%",
    margin:3
  }
});


export default AllUsers;