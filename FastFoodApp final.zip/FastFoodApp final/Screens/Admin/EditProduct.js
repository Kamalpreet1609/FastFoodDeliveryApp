import React, { Component } from 'react'
import {
    StyleSheet,
    View,
    Text,
    TextInput,
    Button,
    TouchableOpacity,
    FlatList, Alert, Picker,
    Image

} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");
var items = [];


class EditProduct extends Component {
    state = {
        displayName: '',
        imageUrl: '',
        id: '',
        oldPName: '',
        category: '',
        price: '',
        description: '',
        categories: []
    }


    componentDidMount() {
        db.transaction(
            tx => {
                tx.executeSql("select title from categories", [], (_, { rows }) => {
                    console.log('Cats', rows._array)
                    this.setState({ categories: rows._array, })

                }
                    , (transact, err) => {
                        console.log('We have encounter an Error', err)
                    }
                );
            },
        );
        let book = this.props.navigation.getParam("newBook");
        if (book != null) {
            console.log("itemData", book);
            this.setState({
                displayName: book.title,
                oldCatName: book.title,
                imageUrl: book.image,
                id: book.id,
                category: book.category,
                price: book.Price,
                description: book.Description
            })
        }


    }

    updateInputVal = (val, prop) => {
        const state = this.state;
        state[prop] = val;
        this.setState(state);
    }

    deleteProduct = () => {
        Alert.alert(
            "Remove Category!",
            "Are you sure you want to delete product " + this.state.displayName + " from app?",
            [{
                text: 'Delete', onPress: () => {
                    db.transaction(
                        tx => {
                            tx.executeSql(
                                "delete from products where id =?"
                                , [this.state.id]
                                , (transact, resultset) => {
                                    console.log('Query Reslts product: ' + resultset)
                                    this.props.navigation.goBack(null);
                                }
                                , (transact, err) => {
                                    console.log('We have encounter an Error Cat', err)
                                }
                            );

                        },

                    );
                }
            }]
        );


    }

    addProduct = () => {
        if (this.state.displayName === '' && this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter product details!')
        } else if (this.state.displayName === '') {
            Alert.alert('Error!', 'Enter Product Name!')
        } else if (this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter Product Image Url!')
        } else if (this.state.description === '') {
            Alert.alert('Error!', 'Enter Product description!')
        } else if (this.state.price === '') {
            Alert.alert('Error!', 'Enter Product price!')
        } else {
            db.transaction(
                tx => {
                    tx.executeSql(
                        "insert into products (category, title, Description, rating, Price, favourite, image) values (?,?,?,?,?,'false',?)"
                        , [this.state.category, this.state.displayName, this.state.description, '3.5', this.state.price, this.state.imageUrl]
                        , (transact, resultset) => {
                            console.log('Query Reslts Cat: ' + resultset)
                            this.props.navigation.goBack(null);
                        }
                        , (transact, err) => {
                            console.log('We have encounter an Error Cat', err)
                        }
                    );

                },

            );
        }
    }
    updateProduct = () => {
        if (this.state.displayName === '' && this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter product details!')
        } else if (this.state.displayName === '') {
            Alert.alert('Error!', 'Enter Product Name!')
        } else if (this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter Product Image Url!')
        } else if (this.state.description === '') {
            Alert.alert('Error!', 'Enter Product description!')
        } else if (this.state.price === '') {
            Alert.alert('Error!', 'Enter Product price!')
        } else {
            db.transaction(
                tx => {
                    let trxQuery = tx.executeSql(
                        "update products set category=?, title=?, Description=?, rating=?, Price=?, favourite = 'false', image =? where id = ?"
                        , [this.state.category, this.state.displayName, this.state.description, '3.5', this.state.price, this.state.imageUrl, this.state.id]
                        , (transact, resultset) => {
                            console.log('Product updated successfully!')
                            this.props.navigation.goBack(null);
                        }
                        , (transact, err) => {
                            console.log('We have encounter an Error', err)
                            alert(err);
                        }
                    );

                },

            );
        }
    }


    static navigationOptions = ({ navigation }) => {
        return {
            title: navigation.getParam("newBook") != null ? navigation.getParam("newBook").title : "Add Product",
        };
    };
    setSelectedValue = (itemValue,itemIndex) => {
        console.log('Cat '+this.state.categories[itemIndex].title, itemValue)
        this.setState({
            category:itemValue
        })
    }
    render() {

        if (this.state.catId == '') {
            return (
                <View style={styles.main}>
                    <Image style={styles.avatar} source={{ uri: this.state.imageUrl != '' ? this.state.imageUrl : 'https://bootdey.com/img/Content/avatar/avatar6.png' }} />

                    <View style={styles.body}>
                        <View style={styles.bodyContent}></View>
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Category"
                            value={this.state.displayName}
                            onChangeText={(val) => this.updateInputVal(val, 'displayName')}
                        />
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Image Url"
                            value={this.state.imageUrl}
                            onChangeText={(val) => this.updateInputVal(val, 'imageUrl')}
                        />

                        <Button
                            color="#0F9E54"
                            title="Add"
                            onPress={() => this.addProduct()}
                        />

                    </View>
                </View>

            )

        } else {
            return (
                <View style={styles.main}>
                    <Image style={styles.avatar} source={{ uri: this.state.imageUrl != '' ? this.state.imageUrl : 'https://bootdey.com/img/Content/avatar/avatar6.png' }} />

                    <View style={styles.body}>
                        <View style={styles.bodyContent}></View>
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Product Name"
                            value={this.state.displayName}
                            onChangeText={(val) => this.updateInputVal(val, 'displayName')}
                        />
                        {/*  <TextInput
                            style={styles.inputStyle}
                            placeholder="Category"
                            value={this.state.category}
                            onChangeText={(val) => this.updateInputVal(val, 'category')}
                        /> */}
                        <Picker
                            mode="dropdown"
                            selectedValue={this.state.category}
                            onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,itemIndex)}>
                            {this.state.categories.map((item, index) => {
                                return (< Picker.Item label={item.title} value={item.title} key={index} />);
                            })}
                        </Picker>
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Product Description"
                            value={this.state.description}
                            multiline={true}
                            onChangeText={(val) => this.updateInputVal(val, 'description')}
                        />
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Product Price"
                            value={this.state.price}
                            onChangeText={(val) => this.updateInputVal(val, 'price')}
                        />
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Image Url"
                            value={this.state.imageUrl}
                            multiline={true}
                            onChangeText={(val) => this.updateInputVal(val, 'imageUrl')}
                        />

                        <Button
                            color="#0F9E54"
                            title="Update"
                            onPress={() => this.updateProduct()}
                        />

                        <View style={styles.body}></View>

                        <Button
                            color="#0F9E54"
                            title="Delete"
                            onPress={() => this.deleteProduct()}
                        />

                    </View>
                </View>

            )
        }
    }
}

const styles = StyleSheet.create({
    main: {
        flex: 1,
        padding: 5,
        backgroundColor: "#f5f5f0",
    },
    item: {
        flex: 1,
        height: 180,
        backgroundColor: "white",
        borderRadius: 5,
        shadowColor: "gray",
        shadowOpacity: 0.4,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        elevation: 2,
        justifyContent: "center",
        alignItems: "center",
        padding: 15,
        margin: 5
    },
    text: {
        fontSize: 15,
        alignContent: "flex-end",
        marginTop: 10

    },
    inputStyle: {
        width: '100%',
        marginBottom: 15,
        paddingBottom: 15,
        alignSelf: "center",
        borderColor: "#ccc",
        borderBottomWidth: 1
    },
    loginText: {
        color: '#3740FE',
        marginTop: 25,
        textAlign: 'center'
    },
    preloader: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff'
    }, avatar: {
        width: 130,
        height: 130,
        borderColor: "white",
        marginBottom: 10,
        alignSelf: 'center',
        marginTop: 30
    },
    body: {
        marginTop: 3,
    },
    bodyContent: {
        flex: 1,
        alignItems: 'center',
        padding: 30,
    },
});



export default EditProduct;











