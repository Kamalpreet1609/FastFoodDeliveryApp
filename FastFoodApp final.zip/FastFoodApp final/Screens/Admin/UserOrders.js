import React, { Component } from 'react'
import {
    StyleSheet,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    FlatList,
    Image,
    Button, Picker
} from 'react-native';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");
import AsyncStorage from '@react-native-async-storage/async-storage'
var options = [
    "Order Placed",
    "Preparing",
    "Out for delivery",
    "Delivered",
];

class UserOrders extends Component {
    state = {
        itemsInList: null,
        userSession: null,
        uid: ''
    }


    static navigationOptions = ({ navigation }) => {
        return {
            title: navigation.getParam("newBook") != null ? navigation.getParam("newBook").name : "User Order",
        };
    };
    checkLogin = () => {
        let book = this.props.navigation.getParam("newBook");
        if (book != null) {
            console.log("itemData", book);
            this.setState({
                uid: book.id,
            })
            this.getOrderList();
        }
    }
    componentDidMount = () => {
        this.checkLogin();
    }
    getOrderList = () => {
        if (this.state.uid != null) {
            db.transaction(
                tx => {
                    tx.executeSql(
                        "select orders.title,orders.ammount,orders.status,orders.uid,orders.oid,order_products.op_id, order_products.p_name,order_products.p_image,order_products.price,order_products.qty from order_products left join orders on order_products.oid = orders.oid where order_products.uid = ?"
                        , [this.state.uid], (_, { rows }) => {
                            console.log('OrderList', rows)
                            this.setState({
                                itemsInList: rows._array
                            });
                        }
                        , (transact, err) => {
                            console.log('We have encounter an Error', err)
                        }
                    );
                },
            );
        } else {
            console.log('Login' + "err")
        }
    }
    updateOrderStatus = (id, status) => {
        //alert("Under Development");
        db.transaction(
            tx => {
                tx.executeSql(
                    "update orders set status= ? where oid = ?"
                    , [status, id]
                    , (transact, resultset) => {
                        console.log('Query Reslts cart', resultset)
                        console.log('Product updated successfully!')
                        this.getOrderList();
                    }
                    , (transact, err) => {
                        console.log('We have encounter an Error', err)
                        alert(err);
                    }
                );

            },

        );
    }

    setSelectedValue = (itemValue, itemIndex) => {
        console.log('oid',itemIndex)
        this.setState({
            status: itemValue
        })
        this.updateOrderStatus(itemIndex,itemValue);
    }

    loadBooks = (book) => {
        let newBook = {
            id: book.item.uid,
            name: book.item.name,
            email: book.item.email,
        }
        return (
            <TouchableOpacity onPress={
                () => {
                }
            }>
                <View style={styles.productMain}>
                    <View style={{ width: "35%", height: 200 }}>
                        <Image style={{ width: "100%", height: "95%", resizeMode: "contain", borderRadius: 5 }}
                            source={{ uri: book.item.p_image }} />
                    </View>
                    <View style={{ justifyContent: "space-around", alignContent: "center", marginLeft: 20, }}>
                        <View style={{ overFlow: "hidden" }}>
                            <Text style={styles.text}>Order Id : {book.item.oid}</Text>
                            <Text numberOfLines={2} style={styles.text}>{book.item.p_name}</Text>
                        </View>
                        <Text style={{ color: "#666666" }}>Order Qty : {book.item.qty}  Item Price: ${book.item.price}</Text>
                        <Picker
                            mode="dropdown"
                            selectedValue={book.item.status}
                            onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue, book.item.oid)}>
                            {options.map((item, index) => {
                                return (< Picker.Item label={item} value={item} key={index} />);
                            })}

                        </Picker>
                        <Text style={styles.text}>Total Amount : ${book.item.price * book.item.qty}</Text>
                    </View>

                </View>
            </TouchableOpacity>
        )

    }

    render() {
        return (
            <View style={styles.main}>

                <FlatList data={this.state.itemsInList}
                    keyExtractor={(item, index) => index + ''}
                    renderItem={
                        this.loadBooks
                    }
                />
            </View>
        )
    }
}
const styles = StyleSheet.create({
    main: {
        flex: 1,
        padding: 10,

    },
    bookMain: {
        marginTop: 10,
        width: "100%",
        height: 500,

        borderColor: "black", borderWidth: 1,
        borderRadius: 5
    },
    productMain: {
        flexDirection: "row",
        justifyContent: "flex-start",
        borderBottomColor: "gray",
        borderBottomWidth: 1,
        marginBottom: 5


    },
    text: {
        color: "black",
        fontSize: 15,
        fontWeight: "bold",
        overflow: "hidden",
        width: "90%",

    }
});


export default UserOrders;