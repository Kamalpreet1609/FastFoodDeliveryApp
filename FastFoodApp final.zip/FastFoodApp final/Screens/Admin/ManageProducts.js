import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  Button

} from 'react-native';
import { NavigationEvents } from 'react-navigation';
import { Rating, AirbnbRating } from 'react-native-ratings';
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import MyHeaderButton from "../MyHeaderButton";
import Fontisto from 'react-native-vector-icons/Fontisto';
import { Avatar, Badge, Icon, withBadge } from 'react-native-elements';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");

class ManageProducts extends Component {

  static navigationOptions = ({ navigation }) => {
    return {
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <HeaderButtons HeaderButtonComponent={MyHeaderButton}>
             <Item title="Favourtie" iconName="plus"
              onPress={() => {
                navigation.navigate("EditProduct");
             }}
            />
          </HeaderButtons> 
    
        </View>
      )
    };
  };
  state = {
    filteredProducts: [],
    allProducts:[],
    count: -12
  }

  constructor(props) {
    super(props);
    props.navigation.addListener('willFocus', () => {
        db.transaction(
            tx => {
              tx.executeSql("select * from products", [], (_, { rows }) => {
                this.setState({
                  filteredProducts: rows._array,
                  allProducts:rows._array
                });
              }
                , (transact, err) => {
                  console.log('We have encounter an Error', err)
                }
              );
            },
          );
          this.props.navigation.setParams({
            count: 0,
          });
    })
  }


  getItemsCount = () => {
    db.transaction(
      tx => {
        tx.executeSql("select * from cart", [], (_, { rows }) => {
          this.props.navigation.setParams({
            count: rows.length,
          });
          this.setState({
            count: rows.length
          });
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );
  }



  searchFilterFunction = (text) => {
    // Check if searched text is not blank
    if (text) {
      // Inserted text is not blank
      // Filter the masterDataSource
      // Update FilteredDataSource
      const newData = this.state.allProducts.filter(
        function (item) {
          const itemData = item.title
            ? item.title.toUpperCase()
            : ''.toUpperCase();
          const textData = text.toUpperCase();
          return itemData.indexOf(textData) > -1;
      });
      this.setState({
        filteredProducts:newData,
        search:text
      })
     /*  setFilteredDataSource(newData);
      setSearch(text); */
    } else {
      // Inserted text is blank
      // Update FilteredDataSource with masterDataSource
      this.setState({
        filteredProducts:this.state.allProducts,
        search:text
      })
    }
  };

  loadBooks = (product) => {
    let newProduct = {
      id: product.item.id,
      title: product.item.title,
      Description: product.item.Description,
      image: product.item.image,
      Price: product.item.Price,
      category: product.item.category,
      rating: product.item.rating,
      favourite: product.item.favourite
    }
    return (
      <TouchableOpacity onPress={
        () => {
          this.props.navigation.navigate("EditProduct",
            { newBook: newProduct });
        }
      }>
        <View style={styles.productMain}>
          <View style={{ width: "35%", height: 200 }}>
            <Image style={{ width: "100%", height: "95%", resizeMode: "contain", borderRadius: 5 }}
              source={{ uri: product.item.image }} />
          </View>
          <View style={{ justifyContent: "space-around", alignContent: "center", marginLeft: 20, }}>
            <View style={{ overFlow: "hidden" }}>
              <Text numberOfLines={2} style={styles.text}>{product.item.title}</Text>
            </View>
            <Text style={{ color: "#666666", width: 250 }}>{product.item.Description}</Text>
            <Text style={styles.text}>Price : ${product.item.Price}</Text>
            <Rating
              style={{ width: 100,marginTop: 5, marginBottom:5 }}
              startingValue={Math.floor(parseInt(product.item.rating))}
              ratingCount={5}
              imageSize={20}
            />
            <Text style={styles.text}>Price : ${product.item.Price}</Text>
          </View>

        </View>
      </TouchableOpacity>
    )

  }




  render() {
    return (
      <View style={styles.main}>
        <NavigationEvents
          onDidFocus={() => {
            this.getItemsCount()
          }}
        />
         <TextInput
          style={{
            borderColor: "white",
            borderRadius: 3,
            borderWidth: 1,
            padding:5,
            backgroundColor: "white"
          }}
          onChangeText={(text) => this.searchFilterFunction(text)}
          value={this.state.search}
          underlineColorAndroid="transparent"
          placeholder="Search Items Here..."
        />
        <FlatList data={this.state.filteredProducts}
          keyExtractor={(item, index) => index + ''}
          renderItem={
            this.loadBooks
          }
        />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 10,

  },
  bookMain: {
    marginTop: 10,
    width: "100%",
    height: 500,

    borderColor: "black", borderWidth: 1,
    borderRadius: 5
  },
  productMain: {
    flexDirection: "row",
    justifyContent: "flex-start",
    borderBottomColor: "gray",
    borderBottomWidth: 1,
    marginBottom: 5


  },
  text: {
    color: "black",
    fontSize: 15,
    fontWeight: "bold",
    overflow: "hidden",
    width: "90%",

  }
});



export default ManageProducts;