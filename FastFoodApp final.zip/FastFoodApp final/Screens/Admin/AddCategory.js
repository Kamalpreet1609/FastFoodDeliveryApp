import React, { Component } from 'react'
import {
    StyleSheet,
    View,
    Text,
    TextInput,
    Button,
    TouchableOpacity,
    FlatList, Alert,
    Image

} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");
var items = [];


class AddCategory extends Component {
    state = {
        displayName: '',
        imageUrl: '',
        catId: '',
        oldCatName: ''
    }

    componentDidMount() {

        let itemData = this.props.navigation.getParam("itemData");
        if (itemData != null) {
            let book = itemData.item;
            console.log("itemData", book);
            this.setState({
                displayName: book.title,
                oldCatName: book.title,
                imageUrl: book.image,
                catId: book.id
            })
        }


    }

    updateInputVal = (val, prop) => {
        const state = this.state;
        state[prop] = val;
        this.setState(state);
    }

    deleteCat = () => {
        Alert.alert(
            "Remove Category!",
            "Are you sure you want to delete category "+this.state.displayName+" from app?",
            [{
              text: 'Delete', onPress: () => {
                db.transaction(
                    tx => {
                        tx.executeSql(
                            "delete from categories where id =?"
                            , [this.state.catId]
                            , (transact, resultset) => {
                                console.log('Query Reslts Cat: ' + resultset)
                                this.props.navigation.goBack(null);
                            }
                            , (transact, err) => {
                                console.log('We have encounter an Error Cat', err)
                            }
                        );
    
                    },
    
                );
              }
            }]
          );
            
        
    }
    
    addCat = () => {
        if (this.state.displayName === '' && this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter Category details!')
        } else if (this.state.displayName === '') {
            Alert.alert('Error!', 'Enter Category Name!')
        } else if (this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter Category Image Url!')
        } else {
            db.transaction(
                tx => {
                    tx.executeSql(
                        "insert into categories (title, image) values (?, ?)"
                        , [this.state.displayName, this.state.imageUrl]
                        , (transact, resultset) => {
                            console.log('Query Reslts Cat: ' + resultset)
                            this.props.navigation.goBack(null);
                        }
                        , (transact, err) => {
                            console.log('We have encounter an Error Cat', err)
                        }
                    );

                },

            );
        }
    }
    updateCat = () => {
        if (this.state.displayName === '' && this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter Category details!')
        } else if (this.state.displayName === '') {
            Alert.alert('Error!', 'Enter Category Name!')
        } else if (this.state.imageUrl === '') {
            Alert.alert('Error!', 'Enter Category Image Url!')
        } else {
            db.transaction(
                tx => {
                    let trxQuery = tx.executeSql(
                        "update categories set title= ?, image= ? where id = ?"
                        , [this.state.displayName, this.state.imageUrl, this.state.catId]
                        , (transact, resultset) => {
                            //console.log('Category updated successfully!')
                            tx.executeSql(
                                "update products set category= ? where category = ?"
                                , [this.state.displayName, this.state.oldCatName]
                                , (transact, resultset) => {
                                    console.log('Category updated successfully!')
                                    this.props.navigation.goBack(null);
                                }
                                , (transact, err) => {
                                    console.log('We have encounter an Error', err)
                                    alert(err);
                                }
                            );
                        }
                        , (transact, err) => {
                            console.log('We have encounter an Error', err)
                            alert(err);
                        }
                    );

                },

            );
        }
    }


    static navigationOptions = ({ navigation }) => {
            return {
                title: navigation.getParam("itemData")!=null?navigation.getParam("itemData").item.title:"Add Category",
            };
    };

    render() {

        if (this.state.catId == '') {
            return (
                <View style={styles.main}>
                    <Image style={styles.avatar} source={{ uri: this.state.imageUrl != '' ? this.state.imageUrl : 'https://bootdey.com/img/Content/avatar/avatar6.png' }} />

                    <View style={styles.body}>
                        <View style={styles.bodyContent}></View>
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Category"
                            value={this.state.displayName}
                            onChangeText={(val) => this.updateInputVal(val, 'displayName')}
                        />
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Image Url"
                            value={this.state.imageUrl}
                            onChangeText={(val) => this.updateInputVal(val, 'imageUrl')}
                        />

                        <Button
                            color="#0F9E54"
                            title="Add"
                            onPress={() => this.addCat()}
                        />

                    </View>
                </View>

            )

        } else {
            return (
                <View style={styles.main}>
                    <Image style={styles.avatar} source={{ uri: this.state.imageUrl != '' ? this.state.imageUrl : 'https://bootdey.com/img/Content/avatar/avatar6.png' }} />

                    <View style={styles.body}>
                        <View style={styles.bodyContent}></View>
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Category"
                            value={this.state.displayName}
                            onChangeText={(val) => this.updateInputVal(val, 'displayName')}
                        />
                        <TextInput
                            style={styles.inputStyle}
                            placeholder="Image Url"
                            value={this.state.imageUrl}
                            onChangeText={(val) => this.updateInputVal(val, 'imageUrl')}
                        />

                        <Button
                            color="#0F9E54"
                            title="Update"
                            onPress={() => this.updateCat()}
                        />
                        
                        <View style={styles.body}></View>

                        <Button
                            color="#0F9E54"
                            title="Delete"
                            onPress = {()=>this.deleteCat()}
                        />

                    </View>
                </View>

            )
        }
    }
}

const styles = StyleSheet.create({
    main: {
        flex: 1,
        padding: 5,
        backgroundColor: "#f5f5f0",

    },
    item: {
        flex: 1,
        height: 180,
        backgroundColor: "white",
        borderRadius: 5,
        shadowColor: "gray",
        shadowOpacity: 0.4,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2,
        elevation: 2,
        justifyContent: "center",
        alignItems: "center",
        padding: 15,
        margin: 5
    },
    text: {
        fontSize: 15,
        alignContent: "flex-end",
        marginTop: 10

    },
    inputStyle: {
        width: '100%',
        marginBottom: 15,
        paddingBottom: 15,
        alignSelf: "center",
        borderColor: "#ccc",
        borderBottomWidth: 1
    },
    loginText: {
        color: '#3740FE',
        marginTop: 25,
        textAlign: 'center'
    },
    preloader: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff'
    }, avatar: {
        width: 130,
        height: 130,
        borderColor: "white",
        marginBottom: 10,
        alignSelf: 'center',
        marginTop: 30
    },
    body: {
        marginTop: 3,
    },
    bodyContent: {
        flex: 1,
        alignItems: 'center',
        padding: 30,
    },
});



export default AddCategory;











