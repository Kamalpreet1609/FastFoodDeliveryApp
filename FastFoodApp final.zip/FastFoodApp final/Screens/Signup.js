import React, { Component } from 'react';
import { StyleSheet, Text, View, TextInput, Button, Alert, ActivityIndicator, CheckBox } from 'react-native';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");

export default class Signup extends Component {

    constructor() {
        super();
        this.state = {
            displayName: '',
            email: '',
            password: '',
            isLoading: false,
            isAdmin: false
        }
    }

    setIsAdmin=(isSelected)=>{
        this.setState({
            isAdmin:isSelected
        })
    }
    updateInputVal = (val, prop) => {
        const state = this.state;
        state[prop] = val;
        this.setState(state);
    }

    registerUser = () => {
        if (this.state.email === '' && this.state.password === '') {
            Alert.alert('Enter details to signup!')
        } else {
            this.setState({
                isLoading: true,
            })
            db.transaction(
                tx => {
                    let trxQuery = tx.executeSql(
                        "insert into users (name, email, pwd, is_active,isAdmin) values (?, ?, ?, 1,?)"
                        , [this.state.displayName, this.state.email, this.state.password,this.state.isAdmin]
                        , (transact, resultset) => {
                            console.log('Query Reslts', resultset)
                            console.log('User registered successfully!')
                            this.setState({
                                isLoading: false,
                                displayName: '',
                                email: '',
                                password: ''
                            })
                            tx.executeSql("select * from users", [], (_, { rows }) =>
                                console.log(JSON.stringify(rows))
                                , (transact, err) => console.log('We have encounter an Error', err)
                            );
                            this.props.navigation.navigate('Login')
                        }
                        , (transact, err) => {
                            console.log('We have encounter an Error', err)
                            alert(err)
                            this.setState({
                                isLoading: false,
                                password: ''
                            })
                        }
                    );
                },

            );

        }
    }

    render() {
        if (this.state.isLoading) {
            return (
                <View style={styles.preloader}>
                    <ActivityIndicator size="large" color="#9E9E9E" />
                </View>
            )
        }
        return (
            <View style={styles.container}>
                <TextInput
                    style={styles.inputStyle}
                    placeholder="Name"
                    value={this.state.displayName}
                    onChangeText={(val) => this.updateInputVal(val, 'displayName')}
                />
                <TextInput
                    style={styles.inputStyle}
                    placeholder="Email"
                    value={this.state.email}
                    onChangeText={(val) => this.updateInputVal(val, 'email')}
                />
                <TextInput
                    style={styles.inputStyle}
                    placeholder="Password"
                    value={this.state.password}
                    onChangeText={(val) => this.updateInputVal(val, 'password')}
                    maxLength={15}
                    secureTextEntry={true}
                />
                <View style={styles.checkboxContainer}>
                    <CheckBox
                        value={this.state.isAdmin}
                        onValueChange={(isSelected)=>{this.setIsAdmin(isSelected)}}
                        style={styles.checkbox}
                    />
                    <Text style={styles.label}>Is Restaurent?</Text>
                </View>

                <Button
                    color="#0F9E54"
                    title="Signin"
                    onPress={() => this.registerUser()}
                />


                <Text
                    style={styles.loginText}
                    onPress={() => this.props.navigation.navigate('Login')}>
                    Already Registered? Click here to login
                </Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: 35,
        backgroundColor: '#fff'
    },
    inputStyle: {
        width: '100%',
        marginBottom: 15,
        paddingBottom: 15,
        alignSelf: "center",
        borderColor: "#ccc",
        borderBottomWidth: 1
    },
    loginText: {
        color: '#3740FE',
        marginTop: 25,
        textAlign: 'center'
    },
    preloader: {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff'
    }, checkboxContainer: {
        flexDirection: "row",
        marginBottom: 20,
    },
    checkbox: {
        alignSelf: "center",
    },
    label: {
        margin: 8,
    },
});