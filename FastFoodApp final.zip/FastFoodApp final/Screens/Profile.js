import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image, Alert,
  TouchableOpacity, AppState, DeviceEventEmitter
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage'

export default class Profile extends Component {
  state = {
    userSession: null
  }
  constructor(props) {
    super(props);
    props.navigation.addListener('willFocus', () => {
      this.checkLogin()
    })
  }
  checkLogin = () => {
    AsyncStorage.getItem("userSession").then((value) => {
      console.log('Login Session', JSON.parse(value));
      this.setState({
        userSession: JSON.parse(value)
      });
    });
  }

  userLogout = () => {
    Alert.alert(
      "Logout!",
      "Are you sure you want to logout from app?",
      [{
        text: 'Logout', onPress: () => {
          AsyncStorage.removeItem("userSession");
          this.setState({
            userSession: null
          });
        }
      }]
    );
  }




  render() {
    this.props.navigation.addListener(
      'didFocus',
      payload => {
        //this.checkLogin();
        //console.log("Payload is called .....................")
      }
    );

    if (this.state.userSession != null) {
      if (this.state.userSession.isAdmin == 1) {
        return (
          <View style={styles.container}>
            <View style={styles.header}></View>
            <View style={styles.body}>
              <View style={styles.bodyContent}>
                <Text style={styles.name}>{this.state.userSession.name}</Text>
                <Text style={styles.info}>{this.state.userSession.email}</Text>

                <TouchableOpacity style={styles.buttonContainer}
                  onPress={() => this.props.navigation.navigate('AllUsers')}>
                  <Text style={{ color: "white", }}>Manage Customers and Orders</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.buttonContainer}
                  onPress={() => this.props.navigation.navigate('Categories')}>
                  <Text style={{ color: "white", }}>Manage Food Categories</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.buttonContainer}
                  onPress={() => this.props.navigation.navigate('ManageProducts')}>
                  <Text style={{ color: "white", }}>Manage Food Products</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.buttonLogout}
                  onPress={() => this.userLogout()}>
                  <Text style={{ color: "white", }}>Log out</Text>
                </TouchableOpacity>

              </View>
            </View>
          </View>
        );
      } else {
        return (
          <View style={styles.container}>
            <View style={styles.header}></View>
            <View style={styles.body}>
              <View style={styles.bodyContent}>
                <Text style={styles.name}>{this.state.userSession.name}</Text>
                <Text style={styles.info}>{this.state.userSession.email}</Text>

                <TouchableOpacity style={styles.buttonContainer}
                  onPress={() => this.props.navigation.navigate('Orders')}>
                  <Text style={{ color: "white", }}>My Orders</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.buttonLogout}
                  onPress={() => this.userLogout()}>
                  <Text style={{ color: "white", }}>Log out</Text>
                </TouchableOpacity>

              </View>
            </View>
          </View>
        );
      }
    }
    return (
      <View style={styles.container}>
        <View style={styles.header}></View>
        <View style={styles.body}>
          <View style={styles.bodyContent}>
            <Text style={styles.name}>Login Required!</Text>
            <Text style={styles.info}>Login into aplication to view profile, complete orders and view order history.</Text>
            <TouchableOpacity style={styles.buttonLogIN}
              onPress={() => this.props.navigation.navigate('Login')}>
              <Text style={{ color: "white", }}>Log in</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );

  }
}

const styles = StyleSheet.create({
  header: {
    height: 100,
  },
  avatar: {
    width: 130,
    height: 130,
    borderRadius: 63,
    borderWidth: 4,
    borderColor: "white",
    marginBottom: 10,
    alignSelf: 'center',
    position: 'absolute',
    marginTop: 30
  },
  name: {
    fontSize: 22,
    color: "#FFFFFF",
    fontWeight: '600',
  },
  body: {
    marginTop: 40,
  },
  bodyContent: {
    flex: 1,
    alignItems: 'center',
    padding: 30,
  },
  name: {
    fontSize: 28,
    color: "#696969",
    fontWeight: "600"
  },
  info: {
    fontSize: 16,
    color: "#00BFFF",
    marginTop: 10
  },
  description: {
    fontSize: 16,
    color: "#696969",
    marginTop: 10,
    textAlign: 'center'
  },
  buttonContainer: {
    marginTop: 10,
    height: 45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    width: 250,
    borderRadius: 30,
    backgroundColor: "#00BFFF",
  },
  buttonLogout: {
    marginTop: 10,
    height: 45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    width: 250,
    borderRadius: 30,
    backgroundColor: "#0F9E54",
  }, buttonLogIN: {
    marginTop: 10,
    height: 45,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    width: 250,
    borderRadius: 30,
    backgroundColor: "#696969",
  },
});
