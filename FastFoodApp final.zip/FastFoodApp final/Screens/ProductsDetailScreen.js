import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
} from 'react-native';
import { Rating, AirbnbRating } from 'react-native-ratings';
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import MyHeaderButton from "./MyHeaderButton";
import { Avatar, Badge, Icon, withBadge } from 'react-native-elements';
import { NavigationEvents } from 'react-navigation';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");

class ProductsDetailScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    return {
      title: navigation.getParam("title"),
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>

        <View>
          <Badge value={navigation.getParam("count")} status="primary"
            containerStyle={{ position: 'absolute', right: 4, zIndex: 999 }}
          />
          <HeaderButtons HeaderButtonComponent={MyHeaderButton}>
            <Item title="Favourtie" iconName="shopping-cart"
              onPress={() => {
                navigation.navigate("Cart");
              }}
              style={{ marginTop: 4 }}
            />
          </HeaderButtons>

        </View>
      </View>
      )
    };
  };
  state = {
    count: 0
  }
  componentDidMount = () => {
   /*  let count = this.props.itemsCount.itemsCount; 
    console.log(count);*/
    this.props.navigation.setParams({
      count: 0,
    });
  }

  getItemsCount = () => {
    /* this.setState({
      count: this.state.count + 1
    },
      () => {
        let count = this.props.itemsCount.itemsCount;
        console.log(count);
        this.props.navigation.setParams({
          count: count,
        });
      }
    ); */
    db.transaction(
      tx => {
        tx.executeSql("select * from cart", [], (_, { rows }) => {
          this.props.navigation.setParams({
            count: rows.length,
          });
          this.setState({
            count: rows.length
          });
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );
  }
  addCartHandler = (book) => {
    alert("Under Development");
    db.transaction(
      tx => {
        tx.executeSql("select * from cart", [], (_, { rows }) => {
          this.props.navigation.setParams({
            count: rows.length,
          });
          this.setState({
            count: rows.length
          });
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );

  }
  addCartHandler = (book) => {
    //alert("Under Development");
    let qty = 1;
    book.quantity = qty;
    //console.log(this.state.count);
    //this.props.addToCart(book);
    db.transaction(
      tx => {
        tx.executeSql("select * from cart where p_id = ?", [book.id], (_, { rows }) => {
          if (rows.length > 0) {
            console.log('User cart: ' + JSON.stringify(rows._array[0].id))
            let trxQuery = tx.executeSql(
              "update cart set qty= ? where p_id = ?"
              , [rows._array[0].qty + 1, rows._array[0].p_id]
              , (transact, resultset) => {
                console.log('Query Reslts cart', resultset)
                console.log('Product updated successfully!')
              }
              , (transact, err) => {
                console.log('We have encounter an Error', err)
                alert(err);
              }
            );
          } else {
            let trxQuery = tx.executeSql(
              "insert into cart (p_name,p_image,price,qty,p_id) values (?, ?, ?, 1,?)"
              , [book.title, book.image, book.Price, book.id]
              , (transact, resultset) => {
                console.log('Query Reslts cart', resultset)
                console.log('Product added successfully!')

                this.props.navigation.setParams({
                  count: this.state.count + 1,
                });
                this.setState({
                  count: this.state.count + 1
                });
              }
              , (transact, err) => {
                console.log('We have encounter an Error', err)
                alert(err);
              }
            );
          }
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );
  }





  render() {

    let book = this.props.navigation.getParam("newBook");
    return (
      <ScrollView>
        <View style={styles.main}>
          <NavigationEvents
            onDidFocus={() => {
              this.getItemsCount()
            }}
          />
          <Image
            source={{ uri: book.image }}
            style={styles.fitImage}
          />
          <View style={styles.infoBox}>
            <Text>Product </Text>
            <Text style={styles.propText}>{book.title}</Text>
          </View>

          <View style={styles.infoBox}>
            <Text>Category</Text>
            <Text style={styles.propText}>{book.category}</Text>
          </View>
          <View style={styles.infoBox}>
            <Text>Price</Text>
            <Text style={styles.propText}>${book.Price}</Text>
          </View>
          <View >
            <View style={{ ...styles.infoBox, flexDirection: "column" }}>
              <Text> Description! </Text>
              <Text>{book.Description}</Text>
            </View>
            <Rating

              startingValue={Math.floor(parseInt(book.rating))}
              ratingCount={5}
              imageSize={40}
              showRating
            />
          </View>
          <View style={{ alignItems: "center" }}>
            <TouchableOpacity style={{
              justifyContent: "center",
              alignItems: "center",
              padding: 10,
              width: "80%",
              backgroundColor: "#0F9E54",
              borderRadius: 3,

              marginBottom: 20,
            }}
              onPress={() => {
                this.addCartHandler(book);
              }}
            >
              <Text style={{ color: "white", fontWeight: "bold", fontSize: 20 }}>Add to Cart</Text>
            </TouchableOpacity>
          </View>

        </View>
      </ScrollView>

    )
  }
}
const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 10,
  },
  rating: {
    marginTop: 10,
    marginBottom: 10
  },
  infoBox: {
    flexDirection: "row",
    justifyContent: "space-between", borderColor: "gray",
    padding: 10,
    marginTop: 15,
  },
  fitImage: {
    zIndex: -1,
    resizeMode: "contain",
    width: "100%",
    height: 430
  },
  fitImageWithSize: {
    height: 100,
    width: 30,
  },
  defaultText: {
    fontSize: 15,
  },
  propText: {
    fontSize: 15,
  }
});


export default ProductsDetailScreen;