import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  Button
} from 'react-native';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");
import AsyncStorage from '@react-native-async-storage/async-storage'

class OrdersScreen extends Component {
  state = {
    itemsInList: null,
    userSession: null
  }
 
  checkLogin = () => {
    AsyncStorage.getItem("userSession").then((value) => {
      console.log('Login Session OrderScreen', JSON.parse(value));
      this.setState({
        userSession: JSON.parse(value)
      });
      this.getOrderList();
    });
  }
  componentDidMount = () => {
    this.checkLogin();
  }
  getOrderList = () => {
    if (this.state.userSession != null) {
      db.transaction(
        tx => {
          tx.executeSql(
            "select orders.title,orders.ammount,orders.status,orders.uid,orders.oid,order_products.op_id, order_products.p_name,order_products.p_image,order_products.price,order_products.qty from order_products left join orders on order_products.oid = orders.oid where order_products.uid = ?"
            , [this.state.userSession.uid], (_, { rows }) => {
              console.log('OrderList', rows)
              this.setState({
                itemsInList: rows._array
              });
            }
            , (transact, err) => {
              console.log('We have encounter an Error', err)
            }
          );
        },
      );
    } else {
      console.log('Login' + "err")
    }
  }

  loadBooks = (book) => {
    let newBook = {
      id: book.item.oid,
      title: book.item.p_name,
      Description: book.item.p_name,
      image: book.item.p_image,
      Price: book.item.Price,
      category: book.item.p_name
    }
    return (
      <TouchableOpacity onPress={
        () => {
        }
      }>
        <View style={styles.productMain}>
          <View style={{ width: "35%", height: 200 }}>
            <Image style={{ width: "100%", height: "95%", resizeMode: "contain", borderRadius: 5 }}
              source={{ uri: book.item.p_image }} />
          </View>
          <View style={{ justifyContent: "space-around", alignContent: "center", marginLeft: 20, }}>
            <View style={{ overFlow: "hidden" }}>
            <Text style={styles.text}>Order Id : {book.item.oid}</Text>
              <Text numberOfLines={2} style={styles.text}>{book.item.p_name}</Text>
            </View>
            <Text style={{ color: "#666666" }}>Order Qty : {book.item.qty}  Item Price: ${book.item.price}</Text>
            <Text style={{ color: "#666666" }}>Order Status : {book.item.status}</Text>
            <Text style={styles.text}>Total Amount : ${book.item.price*book.item.qty}</Text>
          </View>

        </View>
      </TouchableOpacity>
    )

  }

  render() {
    return (
      <View style={styles.main}>
       
        <FlatList data={this.state.itemsInList}
        keyExtractor={(item, index) => index+''}
        renderItem={
          this.loadBooks
        }
        />
      </View>
    )
  }
}
const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 10,

  },
  bookMain: {
    marginTop: 10,
    width: "100%",
    height: 500,

    borderColor: "black", borderWidth: 1,
    borderRadius: 5
  },
  productMain: {
    flexDirection: "row",
    justifyContent: "flex-start",
    borderBottomColor: "gray",
    borderBottomWidth: 1,
    marginBottom: 5


  },
  text: {
    color: "black",
    fontSize: 15,
    fontWeight: "bold",
    overflow: "hidden",
    width: "90%",

  }
});


export default OrdersScreen;