import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  Button
} from 'react-native';
import { NavigationEvents } from 'react-navigation';
import { Rating, AirbnbRating } from 'react-native-ratings';
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import MyHeaderButton from "./MyHeaderButton";
import { Avatar, Badge, withBadge } from 'react-native-elements';
import Fontisto from 'react-native-vector-icons/Fontisto';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");


class CategoriesProductsScreen extends Component {

  state = {
    filteredProducts: [],
    allProducts: [],
    search: '',
    count: 0
  }
  searchFilterFunction = (text) => {
    // Check if searched text is not blank
    if (text) {
      // Inserted text is not blank
      // Filter the masterDataSource
      // Update FilteredDataSource
      const newData = this.state.allProducts.filter(
        function (item) {
          const itemData = item.title
            ? item.title.toUpperCase()
            : ''.toUpperCase();
          const textData = text.toUpperCase();
          return itemData.indexOf(textData) > -1;
        });
      this.setState({
        filteredProducts: newData,
        search: text
      })

    } else {
      // Inserted text is blank
      // Update FilteredDataSource with masterDataSource
      this.setState({
        filteredProducts: this.state.allProducts,
        search: text
      })
    }
  };
  static navigationOptions = ({ navigation }) => {
    return {
      title: navigation.getParam("title"),
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>

          <View>
            <Badge value={navigation.getParam("count")} status="primary"
              containerStyle={{ position: 'absolute', right: 4, zIndex: 999 }}
            />
            <HeaderButtons HeaderButtonComponent={MyHeaderButton}>
              <Item title="Favourtie" iconName="shopping-cart"
                onPress={
                  () => {
                    //alert("Under Development");
                    navigation.navigate("Cart");
                  }
                }
                style={{ marginTop: 4 }}
              />
            </HeaderButtons>

          </View>

        </View>
      )
    };
  };



  componentDidMount = () => {

    let category = this.props.navigation.getParam("title");
    db.transaction(
      tx => {
        tx.executeSql("select * from products where category = ?", [category], (_, { rows }) => {
          this.setState({
            filteredProducts: rows._array,
            allProducts: rows._array
          });
        }
          , (transact, err) => {
            console.log('We have encounter an Error', err)
          }
        );
      },
    );


    this.props.navigation.setParams({
      count: 0,
    });

  }
  getItemsCount = () => {

    db.transaction(
      tx => {
        tx.executeSql("select * from cart", [], (_, { rows }) => {
          this.props.navigation.setParams({
            count: rows.length,
          });
          this.setState({
            count: rows.length
          });
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );

  }
  addCartHandler = (book) => {
    //alert("Under Development");
    let qty = 1;
    book.quantity = qty;
    //console.log(this.state.count);
    //this.props.addToCart(book);
    db.transaction(
      tx => {
        tx.executeSql("select * from cart where p_id = ?", [book.id], (_, { rows }) => {
          if (rows.length > 0) {
            console.log('User cart: ' + JSON.stringify(rows._array[0].id))
            let trxQuery = tx.executeSql(
              "update cart set qty= ? where p_id = ?"
              , [rows._array[0].qty + 1, rows._array[0].p_id]
              , (transact, resultset) => {
                console.log('Query Reslts cart', resultset)
                console.log('Product updated successfully!')
              }
              , (transact, err) => {
                console.log('We have encounter an Error', err)
                alert(err);
              }
            );
          } else {
            let trxQuery = tx.executeSql(
              "insert into cart (p_name,p_image,price,qty,p_id) values (?, ?, ?, 1,?)"
              , [book.title, book.image, book.Price, book.id]
              , (transact, resultset) => {
                console.log('Query Reslts cart', resultset)
                console.log('Product added successfully!')

                this.props.navigation.setParams({
                  count: this.state.count + 1,
                });
                this.setState({
                  count: this.state.count + 1
                });
              }
              , (transact, err) => {
                console.log('We have encounter an Error', err)
                alert(err);
              }
            );
          }
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );
    //this.getItemsCount();
    // this.props.itemsCount.itemsCount
  }

  loadBooks = (product) => {
    let newProduct = {
      id: product.item.id,
      title: product.item.title,
      Description: product.item.Description,
      image: product.item.image,
      Price: product.item.Price,
      category: product.item.category,
      rating: product.item.rating,
      favourite: product.item.favourite
    }
    return (
      <TouchableOpacity onPress={
        () => {
          this.props.navigation.navigate("ProductDetails",
            { newBook: newProduct });
        }
      }>
        <View style={styles.productMain}>
          <View style={{ width: "35%", height: 200, }}>
            <Image style={{ width: "100%", height: "95%", resizeMode: "contain", borderRadius: 5 }}
              source={{ uri: product.item.image }} />
          </View>
          <View style={{ justifyContent: "space-around", alignContent: "center", marginLeft: 20, }}>
            <View style={{ overFlow: "hidden" }}>
              <Text numberOfLines={2} style={styles.text}>{product.item.title}</Text>
            </View>
            <Text style={{ color: "#666666", width: 250 }}>{product.item.Description}</Text>
            <Text style={styles.text}>Price : ${product.item.Price}</Text>
            <Rating
              style={{ width: 100,marginTop: 5, marginBottom:5 }}
              startingValue={Math.floor(parseInt(product.item.rating))}
              ratingCount={5}
              imageSize={20}
            />
            <View style={{ flexDirection: "row" }}>
              <TouchableOpacity style={{
                justifyContent: "center",
                alignItems: "center",
                padding: 10,
                width: 135,
                backgroundColor: "white",
                borderRadius: 3,
                borderColor: "#0F9E54",
                borderWidth: 1,
              }}
                onPress={() => {
                  this.addCartHandler(newProduct);
                }}
              >
                <Text style={{ color: "#0F9E54", fontWeight: "bold" }}>Add to Cart</Text>
              </TouchableOpacity>

            </View>
          </View>

        </View>
      </TouchableOpacity>
    )

  }



  render() {

    return (
      <View style={styles.main}>
        <NavigationEvents
          onDidFocus={() => {
            this.getItemsCount()
          }}
        />
        <TextInput
          style={{
            borderColor: "white",
            borderRadius: 3,
            borderWidth: 1,
            padding: 5,
            backgroundColor: "white"
          }}
          onChangeText={(text) => this.searchFilterFunction(text)}
          value={this.state.search}
          underlineColorAndroid="transparent"
          placeholder="Search Items Here..."
        />
        <FlatList data={this.state.filteredProducts}
          keyExtractor={(item, index) => index + ''}
          renderItem={
            this.loadBooks
          }
        />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 10,

  },
  bookMain: {
    marginTop: 10,
    width: "100%",
    height: 500,
    borderColor: "black", borderWidth: 1,
    borderRadius: 5
  },
  productMain: {
    flexDirection: "row",
    justifyContent: "flex-start",
    borderBottomColor: "gray",
    borderBottomWidth: 1,
    marginBottom: 5
  },
  text: {
    color: "black",
    fontSize: 15,
    fontWeight: "bold",
    overflow: "hidden",
    width: "90%",
  }
});

export default CategoriesProductsScreen;















