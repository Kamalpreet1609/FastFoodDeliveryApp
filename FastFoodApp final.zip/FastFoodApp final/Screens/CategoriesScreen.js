import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  Button,
  TouchableOpacity,
  FlatList,
  Image

} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");
var items = [];


class CategoriesScreen extends Component {
  state = {
    categories: []
  }

  constructor(props) {
    super(props);
    props.navigation.addListener('willFocus', () => {
      db.transaction(
        tx => {
          tx.executeSql("select * from categories", [], (_, { rows }) => {
            this.setState({ categories: rows._array })
          }
            , (transact, err) => {
              console.log('We have encounter an Error', err)
            }
          );
        },
      );
    })
  }

  componentDidMount() {
    /* db.transaction(
      tx => {
        tx.executeSql("select * from categories", [], (_, { rows }) => {
          this.setState({ categories: rows._array })
        }
          , (transact, err) => {
            console.log('We have encounter an Error', err)
          }
        );
      },
    ); */


  }

  renderItemsFunction = (itemData) => {
    return (
      <TouchableOpacity style={styles.item}
        onPress={
          () => {
            this.props.navigation.navigate("CategoriesProducts", { title: itemData.item.title, });
          }
        }>
        <View>
          <Image source={{ uri: itemData.item.image }} style={{ width: 120, height: 120 }} />
        </View>
        <Text style={styles.text} numberOfLines={2}> {itemData.item.title} </Text>

      </TouchableOpacity>
    )
  }

  render() {
    const totalPrice =
      this.state.dataSource &&
      this.state.dataSource.map((item) => item.categories).reduce((prev, next) => prev + next)

    return (

      <View style={styles.main}>
        <FlatList style={{ marginTop: 5 }} data={this.state.categories} numColumns={2}
          keyExtractor={(item, index) => index + ''}
          renderItem={this.renderItemsFunction}
          keyExtractor={item => item.id}
        />
      </View>

    )
  }
}

const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 5,
    backgroundColor: "#f5f5f0",

  },
  item: {
    flex: 1,
    height: 180,
    backgroundColor: "white",
    borderRadius: 5,
    shadowColor: "gray",
    shadowOpacity: 0.4,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 2,
    elevation: 2,
    justifyContent: "center",
    alignItems: "center",
    padding: 15,
    margin: 5
  },
  text: {
    fontSize: 15,
    alignContent: "flex-end",
    marginTop: 10

  },

});



export default CategoriesScreen;











