import React, { Component } from 'react'
import {
  StyleSheet,
  View,
  Text,
  Button,
  Alert,
  TouchableOpacity,
  FlatList,
  Image
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage'
import { NavigationEvents } from 'react-navigation';
import Icon from 'react-native-vector-icons/AntDesign';
import FontAwesome from 'react-native-vector-icons/FontAwesome5';
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import MyHeaderButton from "./MyHeaderButton";
import { Avatar, Badge, withBadge } from 'react-native-elements';
import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase("ffdb.db");

class CartScreen extends Component {

  static navigationOptions = ({ navigation }) => {
    return {
      title: "Items in Cart",
    }
  }
  state = {
    userSession: null,
    itemsInCart: null,
    itemsCount: -1,
  }

  constructor(props) {
    super(props);
    props.navigation.addListener('willFocus', () => {
      this.checkLogin()
    })
  }

  checkLogin = () => {
    AsyncStorage.getItem("userSession").then((value) => {
      console.log('Login Session', JSON.parse(value));
      this.setState({
        userSession: JSON.parse(value)
      });
    });
  }

  componentDidMount = () => {
    this.getItemsCount();
    AsyncStorage.getItem('userSession',
      (rawData) => {
        this.setState({
          userSession: rawData
        });
      },
      (error) => {
        console.log('IsLogedIn Error', error);
        // whatever you want to do here.
      }
    );
  }

  getItemsCount = () => {
    db.transaction(
      tx => {
        tx.executeSql("select * from cart", [], (_, { rows }) => {
          this.setState({
            itemsInCart: rows._array,
            itemsCount: rows.length
          });
        }
          , (transact, err) => {
            console.log('We have encounter an Error', err)
          }
        );
      },
    );

  }


  removeItem = (id) => {
    db.transaction(tx => {
      tx.executeSql(
        "DELETE from cart where p_id = ?"
        // "Drop table categories"
        , [id]
        , (transact, resultset) => {
          console.log('Query Reslts delete cart: ', resultset);
          setTimeout(this.getItemsCount, 1000);
        }//
        , (transact, err) => console.log('We have encounter an Error', err)
      );
    });
  }

  decreaseQty = (id) => {
    db.transaction(
      tx => {
        tx.executeSql("select * from cart where p_id = ?", [id], (_, { rows }) => {
          if (rows.length > 0) {
            console.log('User cart: ' + JSON.stringify(rows._array[0].id))
            let trxQuery = tx.executeSql(
              "update cart set qty= ? where p_id = ?"
              , [rows._array[0].qty - 1, rows._array[0].p_id]
              , (transact, resultset) => {
                setTimeout(this.getItemsCount, 1000);
                console.log('Query Reslts cart', resultset)
                console.log('Product updated successfully!')
              }
              , (transact, err) => {
                console.log('We have encounter an Error', err)
                //alert(err);
              }
            );
          }
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );
  }

  emptyCart = () => {
    db.transaction(tx => {
      tx.executeSql(
        "DELETE from cart"
        , []
        , (transact, resultset) => {
          console.log('Query Reslts delete cart: ', resultset);
          setTimeout(this.getItemsCount, 1000);
        }
        , (transact, err) => console.log('We have encounter an Error', err)
      );
    });
  }

  getOrderList = () => {
    db.transaction(
      tx => {
        tx.executeSql("select * from orders", [], (_, { rows }) => {
          console.log('Order List', rows._array);
        }
          , (transact, err) => {
            console.log('We have encounter an Error', err);
          }
        );
      },
    );
  }

  addItemsToOrder = (id, uid) => {
    this.state.itemsInCart.forEach(element => {
      db.transaction(
        tx => {
          let trxQuery = tx.executeSql(
            "insert into order_products (p_name,p_image,price,qty,oid,uid) values (?, ?, ?, ?,?,?)"
            , [element.p_name, element.p_image, element.price, element.qty, id, uid]
            , (transact, resultset) => {
              console.log('Query Reslts Order', resultset.insertId)
              console.log('Order Item added successfully!')
              Alert.alert(
                "Order Placed!",
                "Thanks for Ordering. You will receive your order in 20-44 Minuts. Cash On Delivery!",
                [{ text: 'OK', onPress: () => console.log('Order Placed Success!') }]
              );
              this.emptyCart();
            }
            , (transact, err) => {
              console.log('We have encounter an Error', err)
              alert(err);
            }
          );
        },

      );
    });
  }

  placeorder = () => {
    var amount = 0;
    this.state.itemsInCart.forEach(element => {
      amount = amount + (element.qty * (element.price));
    });

    db.transaction(
      tx => {
        let trxQuery = tx.executeSql(
          "insert into orders (title,ammount,status,uid) values ('', ?, 'Order Placed', ?)"
          , [amount, this.state.userSession.uid]
          , (transact, resultset) => {
            console.log('Query Reslts Order', resultset.insertId)
            console.log('Order added successfully!')
            this.getOrderList();
            this.addItemsToOrder(resultset.insertId, this.state.userSession.uid)
          }
          , (transact, err) => {
            console.log('We have encounter an Error', err)
            alert(err);
          }
        );
      },

    );

    /*   Alert.alert(
        "Order Placed!",
                "Thanks for Ordering. You will receive your order in 20-44 Minuts. Cash On Delivery!",
        [{ text: 'OK', onPress: () => console.log('Order Placed Success!') }]
      );*/
  }

  increaseQty = (id) => {
    db.transaction(
      tx => {
        tx.executeSql("select * from cart where p_id = ?", [id], (_, { rows }) => {
          if (rows.length > 0) {
            console.log('User cart: ' + JSON.stringify(rows._array[0].id))
            let trxQuery = tx.executeSql(
              "update cart set qty= ? where p_id = ?"
              , [rows._array[0].qty + 1, rows._array[0].p_id]
              , (transact, resultset) => {
                setTimeout(this.getItemsCount, 1000);
                console.log('Query Reslts cart', resultset)
                console.log('Product updated successfully!')
              }
              , (transact, err) => {
                console.log('We have encounter an Error', err)
                //alert(err);
              }
            );
          }
        }
          , (transact, err) => console.log('We have encounter an Error', err)
        );

      },

    );
  }



  loadBooks = (book) => {
    return (
      <View>
        <View style={styles.productMain}>
          <View style={{ width: "35%", height: 130 }}>
            <Image style={{ width: "100%", height: "95%", resizeMode: "contain", borderRadius: 5 }}
              source={{ uri: book.item.p_image }} />
          </View>
          <View style={{ justifyContent: "space-around", alignContent: "center", marginLeft: 20, }}>
            <View style={{ overFlow: "hidden" }}>
              <Text numberOfLines={1} style={styles.text}>{book.item.p_name}</Text>
            </View>
            <Text style={styles.text}>Price : ${book.item.price}</Text>
            <View style={{ flexDirection: "row", marginVertical: 5 }}>
              {book.item.qty > 1 ?
                <TouchableOpacity onPress={
                  () => {
                    this.decreaseQty(book.item.p_id)
                  }
                }>
                  <Icon name="minussquareo" size={25} color="black" style={{ marginRight: 10, marginTop: 2 }} />
                </TouchableOpacity>
                : <TouchableOpacity disabled={true} onPress={
                  () => {
                    this.decreaseQty(book.item.p_id)
                  }
                }>
                  <Icon name="minussquareo" size={25} color="gray" style={{ marginRight: 10, marginTop: 2 }} />
                </TouchableOpacity>
              }


              <Text style={{ fontSize: 20, }}>
                {book.item.qty}
              </Text>
              <TouchableOpacity onPress={
                () => {
                  this.increaseQty(book.item.p_id)
                }
              }>
                <Icon name="plussquareo" size={25} color="black" style={{ marginLeft: 10, marginTop: 2 }} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={
                  () => {
                    this.removeItem(book.item.p_id)
                  }
                }
                style={{ flexDirection: "row", marginLeft: "30%", justifyContent: "space-between", alignItems: "flex-end" }}>
                <FontAwesome name="trash" size={25} color="red" />

              </TouchableOpacity>
            </View>
          </View>

        </View>
      </View>
    )




  }
  render() {
    if (this.state.itemsCount <= 0) {
      return (
        <View style={styles.main}>
          <NavigationEvents
            onDidFocus={() => {
              this.getItemsCount()
            }}
          />
          <Text>You Have No Item in Your Cart List.</Text>
        </View>
      )
    }
    else {
      return (
        <View style={styles.main}>
          <NavigationEvents
            onDidFocus={() => {
              this.getItemsCount()
            }}
          />
          <FlatList data={this.state.itemsInCart}
            keyExtractor={(item, index) => index+''}
            renderItem={
              this.loadBooks
            }
          />
          <TouchableOpacity style={{
            justifyContent: "center",
            alignItems: "center",
            padding: 10,
            width: "90%",
            backgroundColor: "#0F9E54",
            borderRadius: 3,

            marginBottom: 20,
          }}
            onPress={() => {
              if (this.state.userSession != null) {
                this.placeorder();
              } else {
                Alert.alert(
                  "Login!",
                  "Please login into app to place order.",
                  [{ text: 'Login', onPress: () => this.props.navigation.navigate("Login") }]
                );
              }
            }}
          >
            <Text style={{ color: "white", fontWeight: "bold", fontSize: 20 }}>Order Now</Text>
          </TouchableOpacity>
        </View>
      )
    }
  }
}



const styles = StyleSheet.create({
  main: {
    flex: 1,
    padding: 10,
    alignItems: "center",

  },
  bookMain: {
    marginTop: 10,
    width: "100%",
    height: 500,

    borderColor: "black", borderWidth: 1,
    borderRadius: 5
  },
  productMain: {
    flexDirection: "row",
    justifyContent: "flex-start",
    borderBottomColor: "gray",
    borderBottomWidth: 1,
    marginBottom: 5


  },
  text: {
    color: "black",
    fontSize: 15,
    fontWeight: "bold",
    overflow: "hidden",
    width: "90%",
  }
});

export default CartScreen;